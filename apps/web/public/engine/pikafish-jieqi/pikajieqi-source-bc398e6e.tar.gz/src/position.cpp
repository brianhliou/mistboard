/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2025 The Stockfish developers (see AUTHORS file)

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "position.h"
#include "jieqi_chase.h"

#include <algorithm>
#include <array>
#include <cassert>
#include <cctype>
#include <cstddef>
#include <cstring>
#include <iomanip>
#include <sstream>
#include <string_view>
#include <utility>

#include "bitboard.h"
#include "misc.h"
#include "movegen.h"
#include "tt.h"
#include "uci.h"

using std::string;

namespace Stockfish {

bool JieqiJqeV1 = false;

namespace Zobrist {

Key psq[PIECE_NB + 1][SQUARE_NB];
Key side, noPawns;
Key noCapture[121], jqeRule;
}

namespace {

constexpr std::string_view PieceToChar(" RACPNBK racpnbkXx");

constexpr std::string_view DarkPieces("RNBAKABNR"
                                      "........."
                                      ".C.....C."
                                      "P.P.P.P.P"
                                      "........."
                                      "........."
                                      "p.p.p.p.p"
                                      ".c.....c."
                                      "........."
                                      "rnbakabnr");

static constexpr Piece Pieces[] = {W_ROOK, W_ADVISOR, W_CANNON, W_PAWN, W_KNIGHT, W_BISHOP, W_KING,
                                   B_ROOK, B_ADVISOR, B_CANNON, B_PAWN, B_KNIGHT, B_BISHOP, B_KING};
}  // namespace

// Returns an ASCII representation of the position
std::ostream& operator<<(std::ostream& os, const Position& pos) {

    os << "\n +---+---+---+---+---+---+---+---+---+\n";

    for (Rank r = RANK_9; r >= RANK_0; --r)
    {
        for (File f = FILE_A; f <= FILE_I; ++f)
        {
            Square sq = make_square(f, r);
            Piece  pc = pos.piece_on(sq);
            os << " | " << (pos.is_dark(sq) ? "Xx"[color_of(pc)] : PieceToChar[pc]);
        }

        os << " | " << int(r) << "\n +---+---+---+---+---+---+---+---+---+\n";
    }

    os << "   a   b   c   d   e   f   g   h   i\n"
       << "\nFen: " << pos.fen() << "\nKey: " << std::hex << std::uppercase << std::setfill('0')
       << std::setw(16) << pos.key() << std::setfill(' ') << std::dec << "\nCheckers: ";

    for (Bitboard b = pos.checkers(); b;)
        os << UCIEngine::square(pop_lsb(b)) << " ";

    return os;
}


// Initializes at startup the various arrays used to compute hash keys
void Position::init() {

    PRNG rng(1070372);

    for (Piece pc : Pieces)
        for (Square s = SQ_A0; s <= SQ_I9; ++s)
            Zobrist::psq[pc][s] = rng.rand<Key>();

    for (Square s = SQ_A0; s <= SQ_I9; ++s)
        Zobrist::psq[DARK_PIECE][s] = rng.rand<Key>();

    Zobrist::side    = rng.rand<Key>();
    Zobrist::noPawns = rng.rand<Key>();
    for (Key& k : Zobrist::noCapture)
        k = rng.rand<Key>();
    Zobrist::jqeRule = rng.rand<Key>();
}


// Initializes the position object with the given FEN string.
// This function is not very robust - make sure that input FENs are correct,
// this is assumed to be the responsibility of the GUI.
Position& Position::set(const string& fenStr, StateInfo* si) {
    // Five fields: board, turn, hidden identity pool, no-capture plies, fullmove.
    // Soldier moves and reveals do not reset the no-capture clock.
    unsigned char      token;
    size_t             idx;
    Square             sq = SQ_A9;
    std::istringstream ss(fenStr);

    std::memset(this, 0, sizeof(Position));

    std::memset(si, 0, sizeof(StateInfo));
    st = si;

    ss >> std::noskipws;

    // 1. Piece placement
    while ((ss >> token) && !isspace(token))
    {
        if (isdigit(token))
            sq += (token - '0') * EAST;  // Advance the given number of files

        else if (token == '/')
            sq += 2 * SOUTH;

        else if ((idx = PieceToChar.find(token)) != string::npos)
        {
            if (tolower(token) == 'x')
            {
                idx = PieceToChar.find(DarkPieces[sq]);
                byTypeBB[DARK] |= sq;
            }
            put_piece(Piece(idx), sq);
            if (type_of(Piece(idx)) == KING)
                kingSquare[color_of(Piece(idx))] = sq;
            ++sq;
        }
    }

    // 2. Active color
    ss >> token;
    sideToMove = (token == 'w' ? WHITE : BLACK);
    ss >> token;

    // 3. Hidden identity pool. X is the empty-pool marker.
    std::string pool;
    ss >> std::skipws >> pool;
    std::istringstream poolStream(pool);
    while (poolStream >> token)
    {
        idx = PieceToChar.find(token);
        if (idx != string::npos && idx > 0 && idx < PIECE_NB && type_of(Piece(idx)) != KING)
            poolStream >> restPieces[idx];
    }

    // 4-5. No-capture plies and fullmove number.
    ss >> st->rule40 >> gamePly;
    st->rule40 = std::max(0, st->rule40);

    // Convert from fullmove starting from 1 to gamePly starting from 0,
    // handle also common incorrect FEN with fullmove = 0.
    gamePly = std::max(2 * (gamePly - 1), 0) + (sideToMove == BLACK);

    set_state();

    assert(pos_is_ok());

    return *this;
}


// Sets king attacks to detect if a move gives check
void Position::set_check_info() const {

    update_blockers<WHITE>();
    update_blockers<BLACK>();

    Square ksq = king_square(~sideToMove);

    // We have to take special cares about the cannon and checks
    st->needSlowCheck =
      checkers() || (attacks_bb<ROOK>(king_square(sideToMove)) & pieces(~sideToMove, CANNON));

    st->checkSquares[PAWN]    = attacks_bb<PAWN_TO>(ksq, sideToMove);
    st->checkSquares[KNIGHT]  = attacks_bb<KNIGHT_TO>(ksq, pieces());
    st->checkSquares[CANNON]  = attacks_bb<CANNON>(ksq, pieces());
    st->checkSquares[ROOK]    = attacks_bb<ROOK>(ksq, pieces());
    st->checkSquares[ADVISOR] = attacks_bb<ADVISOR>(ksq);
    st->checkSquares[BISHOP]  = attacks_bb<BISHOP>(ksq, pieces());
    st->checkSquares[KING]    = 0;

    Bitboard hollowCannons = st->checkSquares[ROOK] & pieces(sideToMove, CANNON);
    if (hollowCannons)
    {
        Bitboard hollowCannonDiscover = Bitboard(0);
        while (hollowCannons)
            hollowCannonDiscover |= between_bb(ksq, pop_lsb(hollowCannons));
        for (PieceType pt = ROOK; pt < KING; ++pt)
            st->checkSquares[pt] |= hollowCannonDiscover;
    }
}


// Computes the hash keys of the position, and other
// data that once computed is updated incrementally as moves are made.
// The function is only used when a new position is set up
void Position::set_state() const {

    st->key               = 0;
    st->minorPieceKey     = 0;
    st->nonPawnKey[WHITE] = st->nonPawnKey[BLACK] = 0;
    st->pawnKey                                   = Zobrist::noPawns;
    st->majorMaterial[WHITE] = st->majorMaterial[BLACK] = VALUE_ZERO;
    st->checkersBB = checkers_to(~sideToMove, king_square(sideToMove));
    st->move       = Move::none();

    set_check_info();

    for (Bitboard b = pieces(); b;)
    {
        Square    s  = pop_lsb(b);
        Piece     pc = piece_on(s);
        PieceType pt = type_of(pc);

        st->key ^= Zobrist::psq[is_dark(s) ? DARK_PIECE : pc][s];

        if (pt == PAWN)
            st->pawnKey ^= Zobrist::psq[pc][s];

        else
        {
            st->nonPawnKey[color_of(pc)] ^= Zobrist::psq[pc][s];

            if (pt != KING && (pt & 1))
            {
                st->majorMaterial[color_of(pc)] += PieceValue[pc];
                if (pt != ROOK)
                    st->minorPieceKey ^= Zobrist::psq[pc][s];
            }
        }
    }

    for (const auto& color : {WHITE, BLACK})
        for (const auto& [piece, count] : rest_pieces(color))
            for (int i = 0; i < count; ++i)
                st->key ^= Zobrist::psq[piece][i];

    if (sideToMove == BLACK)
        st->key ^= Zobrist::side;
}


// Returns a FEN representation of the position.
string Position::fen() const {

    int                emptyCnt;
    std::ostringstream ss;

    for (Rank r = RANK_9; r >= RANK_0; --r)
    {
        for (File f = FILE_A; f <= FILE_I; ++f)
        {
            for (emptyCnt = 0; f <= FILE_I && empty(make_square(f, r)); ++f)
                ++emptyCnt;

            if (emptyCnt)
                ss << emptyCnt;

            if (f <= FILE_I)
            {
                Piece pc = piece_on(make_square(f, r));
                ss << (is_dark(make_square(f, r)) ? "Xx"[color_of(pc)] : PieceToChar[pc]);
            }
        }

        if (r > RANK_0)
            ss << '/';
    }

    ss << (sideToMove == WHITE ? " w " : " b ");

    bool hasPool = false;
    for (Color c : {WHITE, BLACK})
        for (PieceType pt = ROOK; pt < KING; ++pt)
        {
            Piece pc = make_piece(c, pt);
            if (restPieces[pc] > 0)
            {
                hasPool = true;
                ss << PieceToChar[pc] << restPieces[pc];
            }
        }
    if (!hasPool)
        ss << "X";

    ss << " " << st->rule40 << " " << 1 + (gamePly - (sideToMove == BLACK)) / 2;

    return ss.str();
}


// Calculates st->blockersForKing[c] and st->pinners[~c],
// which store respectively the pieces preventing king of color c from being in check
// and the slider pieces of color ~c pinning pieces of color c to the king.
template<Color c>
void Position::update_blockers() const {

    Square ksq             = king_square(c);
    st->blockersForKing[c] = 0;
    st->pinners[~c]        = 0;

    // Snipers are pieces that attack 's' when a piece and other pieces are removed
    Bitboard snipers =
      ((attacks_bb<ROOK>(ksq) & (pieces(ROOK) | pieces(CANNON) | pieces(KING)))
       | (attacks_bb<KNIGHT>(ksq) & pieces(KNIGHT)) | (attacks_bb<BISHOP>(ksq) & pieces(BISHOP)))
      & pieces(~c);
    Bitboard occupancy = pieces() ^ (snipers & ~pieces(CANNON));

    while (snipers)
    {
        Square   sniperSq = pop_lsb(snipers);
        bool     isCannon = type_of(piece_on(sniperSq)) == CANNON;
        Bitboard b = between_bb(ksq, sniperSq) & (isCannon ? pieces() ^ sniperSq : occupancy);

        if (b && ((!isCannon && !more_than_one(b)) || (isCannon && popcount(b) == 2)))
        {
            st->blockersForKing[c] |= b;
            if (b & pieces(c))
                st->pinners[~c] |= sniperSq;
        }
    }
}


// Computes a bitboard of all pieces which attack a given square.
// Slider attacks use the occupied bitboard to indicate occupancy.
Bitboard Position::attackers_to(Square s, Bitboard occupied) const {

    return (attacks_bb<PAWN_TO>(s, WHITE) & pieces(WHITE, PAWN))
         | (attacks_bb<PAWN_TO>(s, BLACK) & pieces(BLACK, PAWN))
         | (attacks_bb<KNIGHT_TO>(s, occupied) & pieces(KNIGHT))
         | (attacks_bb<ROOK>(s, occupied) & pieces(ROOK))
         | (attacks_bb<CANNON>(s, occupied) & pieces(CANNON))
         | (attacks_bb<BISHOP>(s, occupied) & pieces(BISHOP))
         | (attacks_bb<ADVISOR>(s) & pieces(ADVISOR)) | (attacks_bb<KING>(s) & pieces(KING));
}


// Computes a bitboard of all pieces of a given color
// which gives check to a given square. Slider attacks use the occupied bitboard
// to indicate occupancy.
Bitboard Position::checkers_to(Color c, Square s, Bitboard occupied) const {

    return ((attacks_bb<PAWN_TO>(s, c) & pieces(PAWN))
            | (attacks_bb<KNIGHT_TO>(s, occupied) & pieces(KNIGHT))
            | (attacks_bb<ROOK>(s, occupied) & pieces(KING, ROOK))
            | (attacks_bb<CANNON>(s, occupied) & pieces(CANNON))
            | (attacks_bb<BISHOP>(s, occupied) & pieces(BISHOP))
            | (attacks_bb<ADVISOR>(s, occupied) & pieces(ADVISOR)))
         & pieces(c);
}


// Tests whether a pseudo-legal move is legal
bool Position::legal(Move m) const {

    assert(m.is_ok());

    Color    us       = sideToMove;
    Square   from     = m.from_sq();
    Square   to       = m.to_sq();
    Bitboard occupied = (pieces() ^ from) | to;

    assert(color_of(moved_piece(m)) == us);
    assert(piece_on(king_square(us)) == make_piece(us, KING));

    // If the moving piece is a dark advisor, make sure the destination square
    // is within the palace
    if (type_of(piece_on(from)) == ADVISOR && move_dark(m) && !(Palace & to))
        return false;

    // If the moving piece is a king, check whether the destination square is
    // attacked by the opponent.
    if (type_of(piece_on(from)) == KING)
        return !(checkers_to(~us, to, occupied));

    // If we don't need slow check. A non-king move is always legal when either:
    // 1. Not moving a pinned piece.
    // 2. Moving a pinned non-cannon piece and aligned with king.
    // 3. Moving a pinned cannon and aligned with king but it's not a capture move.
    if (!st->needSlowCheck
        && (!(blockers_for_king(us) & from)
            || (((type_of(piece_on(from)) != CANNON) || !capture(m))
                && aligned(from, to, king_square(us)))))
        return true;

    // A non-king move is legal if the king is not under attack after the move.
    return !(checkers_to(~us, king_square(us), occupied) & ~square_bb(to));
}


// Takes a random move and tests whether the move is
// pseudo-legal. It is used to validate moves from TT that can be corrupted
// due to SMP concurrent access or hash position key aliasing.
bool Position::pseudo_legal(const Move m) const {

    Color  us   = sideToMove;
    Square from = m.from_sq();
    Square to   = m.to_sq();
    Piece  pc   = moved_piece(m);

    // If the 'from' square is not occupied by a piece belonging to the side to
    // move, the move is obviously not legal.
    if (pc == NO_PIECE || color_of(pc) != us)
        return false;

    // The destination square cannot be occupied by a friendly piece
    if (pieces(us) & to)
        return false;

    // Handle the special cases
    if (type_of(pc) == PAWN)
        return bool(attacks_bb<PAWN>(from, us) & to);
    else if (type_of(pc) == CANNON && !capture(m))
        return bool(attacks_bb<ROOK>(from, pieces()) & to);
    else
        return bool(attacks_bb(type_of(pc), from, pieces()) & to);
}


// Tests whether a pseudo-legal move gives a check
bool Position::gives_check(Move m) const {

    assert(m.is_ok());
    assert(color_of(moved_piece(m)) == sideToMove);

    Square from = m.from_sq();
    Square to   = m.to_sq();
    Square ksq  = king_square(~sideToMove);

    PieceType pt = type_of(moved_piece(m));

    // Is there a direct check?
    if (pt == CANNON && aligned(from, to, ksq))
    {
        if (attacks_bb<CANNON>(to, (pieces() ^ from) | to) & ksq)
            return true;
    }
    else if (check_squares(pt) & to)
        return true;

    // Is there a discovered check?
    if (attacks_bb<ROOK>(ksq) & pieces(sideToMove, CANNON))
        return bool(checkers_to(sideToMove, ksq, (pieces() ^ from) | to) & ~square_bb(from));
    else if ((blockers_for_king(~sideToMove) & from) && !aligned(from, to, ksq))
        return true;

    return false;
}


Piece Position::do_flip(Square s, Piece pc, DirtyPiece* dp, const TranspositionTable* tt) {

    assert(is_ok(s) && is_dark(s));

    Color us     = ~sideToMove;
    Color them   = ~us;
    Piece fromPc = piece_on(s);

    if (dp)
    {
        dp->add_pc = pc;
        dp->add_sq = s;
    }

    assert(color_of(pc) == us);

    // Flip the piece
    remove_piece(s);
    put_piece(pc, s);
    byTypeBB[DARK] ^= s;
    restPieces[pc]--;

    // Recalculate checkersBB
    st->checkersBB = checkers_to(us, king_square(them));

    // Update hash key
    st->key ^= Zobrist::psq[pc][s] ^ Zobrist::psq[pc][restPieces[pc]];
    // If the moving piece is a pawn, update pawn hash key.
    if (type_of(pc) == PAWN)
        st->pawnKey ^= Zobrist::psq[pc][s];
    else
    {
        st->nonPawnKey[us] ^= Zobrist::psq[pc][s];

        if (type_of(pc) == KNIGHT || type_of(pc) == CANNON)
            st->minorPieceKey ^= Zobrist::psq[pc][s];

        if (type_of(pc) != KING && (type_of(pc) & 1))
            st->majorMaterial[us] += PieceValue[pc];
    }

    if (tt)
        prefetch(tt->first_entry(key()));

    // Update king attacks used for fast check detection
    set_check_info();

    assert(pos_is_ok());

    return fromPc;
}


void Position::undo_flip(Square s, Piece fromPc) {

    assert(is_ok(s) && !is_dark(s));

    Color us = ~sideToMove;
    Piece pc = piece_on(s);

    restPieces[pc]++;
    remove_piece(s);
    put_piece(fromPc, s);
    byTypeBB[DARK] ^= s;

    // Update hash key
    st->key ^= Zobrist::psq[pc][s] ^ Zobrist::psq[pc][restPieces[pc]];
    // If the moving piece is a pawn, update pawn hash key.
    if (type_of(pc) == PAWN)
        st->pawnKey ^= Zobrist::psq[pc][s];
    else
    {
        st->nonPawnKey[us] ^= Zobrist::psq[pc][s];

        if (type_of(pc) == KNIGHT || type_of(pc) == CANNON)
            st->minorPieceKey ^= Zobrist::psq[pc][s];

        if (type_of(pc) != KING && (type_of(pc) & 1))
            st->majorMaterial[us] -= PieceValue[pc];
    }

    assert(pos_is_ok());
}


// Makes a move, and saves all information necessary
// to a StateInfo object. The move is assumed to be legal. Pseudo-legal
// moves should be filtered out before this function is called.
// If a pointer to the TT table is passed, the entry for the new position
// will be prefetched
DirtyPiece Position::do_move(Move                      m,
                             StateInfo&                newSt,
                             bool                      givesCheck,
                             const TranspositionTable* tt = nullptr) {

    assert(m.is_ok());
    assert(&newSt != st);

    // Update the bloom filter
    ++filter[st->key];

    Key k = st->key ^ Zobrist::side;

    // Copy some fields of the old state to our new StateInfo object except the
    // ones which are going to be recalculated from scratch anyway and then switch
    // our state pointer to point to the new (ready to be updated) state.
    std::memcpy(&newSt, st, offsetof(StateInfo, key));
    newSt.previous = st;
    st             = &newSt;
    st->move       = m;

    Color  us       = sideToMove;
    Color  them     = ~us;
    Square from     = m.from_sq();
    Square to       = m.to_sq();
    Piece  pc       = piece_on(from);
    Piece  captured = piece_on(to);
    bool   moveDark = move_dark(m);

    DirtyPiece dp;
    dp.pc     = moveDark ? DARK_PIECE : pc;
    dp.from   = from;
    dp.to     = moveDark ? SQ_NONE : to;
    dp.add_sq = SQ_NONE;

    assert(color_of(pc) == us);
    assert(captured == NO_PIECE || color_of(captured) == them);
    assert(type_of(captured) != KING);

    // Increment ply counters.
    // In particular, rule40 will be reset to zero later on in case of a capture.
    ++gamePly;
    ++st->rule40;
    ++st->pliesFromNull;
    ++st->pliesSinceIrreversible;
    if (captured || moveDark)
        st->pliesSinceIrreversible = 0;

    if (pc == make_piece(us, KING))
    {
        dp.requires_refresh[us] = true;
        bool mirror_before = Eval::NNUE::FeatureSet::KingBuckets[king_square(them)][from].second;
        bool mirror_after  = Eval::NNUE::FeatureSet::KingBuckets[king_square(them)][to].second;
        dp.requires_refresh[them] = (mirror_before != mirror_after);
    }
    else
        dp.requires_refresh[us] = dp.requires_refresh[them] = false;

    if (captured)
    {
        Square capsq = to;

        st->captureDark = is_dark(to);

        // If the captured piece is a pawn, update pawn hash key, otherwise
        // update major material.
        if (type_of(captured) == PAWN)
            st->pawnKey ^= Zobrist::psq[captured][capsq];

        else
        {
            st->nonPawnKey[them] ^= Zobrist::psq[captured][capsq];

            if (type_of(captured) & 1)
            {
                st->majorMaterial[them] -= PieceValue[captured];
                if (type_of(captured) != ROOK)
                    st->minorPieceKey ^= Zobrist::psq[captured][capsq];
            }
        }

        dp.remove_pc = st->captureDark ? DARK_PIECE : captured;
        dp.remove_sq = capsq;

        if (st->captureDark)
            byTypeBB[DARK] ^= to;

        // Update board and piece lists
        remove_piece(capsq);

        // Update hash key
        k ^= Zobrist::psq[st->captureDark ? DARK_PIECE : captured][capsq];

        // Reset rule 40 counter
        st->rule40 = 0;
    }
    else
    {
        st->captureDark = false;
        dp.remove_sq    = SQ_NONE;
    }

    // Update hash key
    k ^= moveDark ? Zobrist::psq[DARK_PIECE][from] : Zobrist::psq[pc][from] ^ Zobrist::psq[pc][to];
    // If the moving piece is a pawn, update pawn hash key.
    if (type_of(pc) == PAWN)
        st->pawnKey ^= Zobrist::psq[pc][from] ^ (moveDark ? 0 : Zobrist::psq[pc][to]);
    else
    {
        st->nonPawnKey[us] ^= Zobrist::psq[pc][from] ^ (moveDark ? 0 : Zobrist::psq[pc][to]);

        if (type_of(pc) == KNIGHT || type_of(pc) == CANNON)
            st->minorPieceKey ^= Zobrist::psq[pc][from] ^ (moveDark ? 0 : Zobrist::psq[pc][to]);

        if (moveDark && type_of(pc) != KING && (type_of(pc) & 1))
            st->majorMaterial[us] -= PieceValue[pc];
    }

    // Move the piece.
    move_piece(from, to);

    // Update the key with the final value
    st->key = k;
    if (!moveDark && tt)
        prefetch(tt->first_entry(key()));

    // Set capture piece
    st->capturedPiece = captured;

    // Calculate checkers bitboard (if move gives check)
    st->checkersBB = !moveDark && givesCheck ? checkers_to(us, king_square(them)) : Bitboard(0);
    assert(moveDark || givesCheck == bool(st->checkersBB));

    sideToMove = ~sideToMove;

    // Update king attacks used for fast check detection
    if (!moveDark)
        set_check_info();
    else
        byTypeBB[DARK] ^= from | to;

    assert(pos_is_ok());

    assert(dp.pc != NO_PIECE);
    assert(!bool(captured) ^ (dp.remove_sq != SQ_NONE));
    assert(dp.from != SQ_NONE && (moveDark || dp.to != SQ_NONE));
    assert(dp.add_sq == SQ_NONE);
    return dp;
}


// Unmakes a move. When it returns, the position should
// be restored to exactly the same state as before the move was made.
void Position::undo_move(Move m) {

    assert(m.is_ok());

    sideToMove = ~sideToMove;

    Square from = m.from_sq();
    Square to   = m.to_sq();

    assert(empty(from));
    assert(type_of(st->capturedPiece) != KING);

    if (is_dark(to))
        byTypeBB[DARK] ^= from | to;  // Update dark pieces bitboard

    move_piece(to, from);  // Put the piece back at the source square

    if (st->capturedPiece)
    {
        Square capsq = to;

        put_piece(st->capturedPiece, capsq);  // Restore the captured piece

        if (st->captureDark)
            byTypeBB[DARK] ^= capsq;
    }

    // Finally point our state pointer back to the previous state
    st = st->previous;
    --gamePly;

    // Update the bloom filter
    --filter[st->key];

    assert(pos_is_ok());
}


// Used to do a "null move": it flips
// the side to move without executing any move on the board.
void Position::do_null_move(StateInfo& newSt, const TranspositionTable& tt) {

    assert(!checkers());
    assert(&newSt != st);

    // Update the bloom filter
    ++filter[st->key];

    std::memcpy(&newSt, st, sizeof(StateInfo));

    newSt.previous = st;
    st             = &newSt;

    st->key ^= Zobrist::side;
    prefetch(tt.first_entry(key()));

    st->pliesFromNull = 0;

    sideToMove = ~sideToMove;

    set_check_info();

    assert(pos_is_ok());
}


// Must be used to undo a "null move"
void Position::undo_null_move() {

    assert(!checkers());

    st         = st->previous;
    sideToMove = ~sideToMove;

    // Update the bloom filter
    --filter[st->key];
}


// Tests if the SEE (Static Exchange Evaluation)
// value of move is greater or equal to the given threshold. We'll use an
// algorithm similar to alpha-beta pruning with a null window.
bool Position::see_ge(Move m, int threshold) const {

    assert(m.is_ok());

    Square from = m.from_sq(), to = m.to_sq();

    int swap = PieceValue[piece_on(to)] - threshold;
    if (swap < 0)
        return false;

    swap = PieceValue[piece_on(from)] - swap;
    if (swap <= 0)
        return true;

    assert(color_of(piece_on(from)) == sideToMove);
    Bitboard occupied  = pieces() ^ from ^ to;  // xoring to is important for pinned piece logic
    Color    stm       = sideToMove;
    Bitboard attackers = attackers_to(to, occupied);

    // Flying general
    if (attackers & pieces(stm, KING))
        attackers |= attacks_bb<ROOK>(to, occupied & ~pieces(ROOK)) & pieces(~stm, KING);
    if (attackers & pieces(~stm, KING))
        attackers |= attacks_bb<ROOK>(to, occupied & ~pieces(ROOK)) & pieces(stm, KING);

    Bitboard nonCannons = attackers & ~pieces(CANNON);
    Bitboard cannons    = attackers & pieces(CANNON);
    Bitboard stmAttackers, bb;
    int      res = 1;

    while (true)
    {
        stm = ~stm;
        attackers &= occupied;

        // If stm has no more attackers then give up: stm loses
        if (!(stmAttackers = attackers & pieces(stm)))
            break;

        // Don't allow pinned pieces to attack as long as there are
        // pinners on their original square.
        if (pinners(~stm) & occupied)
        {
            stmAttackers &= ~blockers_for_king(stm);

            if (!stmAttackers)
                break;
        }

        res ^= 1;

        // Locate and remove the next least valuable attacker, and add to the
        // bitboard 'attackers' any protential attackers when it is removed.
        if ((bb = stmAttackers & pieces(PAWN)))
        {
            if ((swap = PawnValue - swap) < res)
                break;
            occupied ^= least_significant_square_bb(bb);

            nonCannons |= attacks_bb<ROOK>(to, occupied) & pieces(ROOK);
            cannons   = attacks_bb<CANNON>(to, occupied) & pieces(CANNON);
            attackers = nonCannons | cannons;
        }

        else if ((bb = stmAttackers & pieces(BISHOP)))
        {
            if ((swap = BishopValue - swap) < res)
                break;
            occupied ^= least_significant_square_bb(bb);
        }

        else if ((bb = stmAttackers & pieces(ADVISOR)))
        {
            if ((swap = AdvisorValue - swap) < res)
                break;
            occupied ^= least_significant_square_bb(bb);

            nonCannons |= attacks_bb<KNIGHT_TO>(to, occupied) & pieces(KNIGHT);
            attackers = nonCannons | cannons;
        }

        else if ((bb = stmAttackers & pieces(CANNON)))
        {
            if ((swap = CannonValue - swap) < res)
                break;
            occupied ^= least_significant_square_bb(bb);

            cannons   = attacks_bb<CANNON>(to, occupied) & pieces(CANNON);
            attackers = nonCannons | cannons;
        }

        else if ((bb = stmAttackers & pieces(KNIGHT)))
        {
            if ((swap = KnightValue - swap) < res)
                break;
            occupied ^= least_significant_square_bb(bb);
        }

        else if ((bb = stmAttackers & pieces(ROOK)))
        {
            swap = RookValue - swap;
            occupied ^= least_significant_square_bb(bb);

            nonCannons |= attacks_bb<ROOK>(to, occupied) & pieces(ROOK);
            cannons   = attacks_bb<CANNON>(to, occupied) & pieces(CANNON);
            attackers = nonCannons | cannons;
        }

        else  // KING
              // If we "capture" with the king but the opponent still has attackers,
              // reverse the result.
            return (attackers & ~pieces(stm)) ? res ^ 1 : res;
    }

    return bool(res);
}


// TT scores must not leak across clocks or between legacy and stamped games.
Key Position::key() const {
    return st->key ^ Zobrist::noCapture[std::min(st->rule40, 120)]
         ^ (JieqiJqeV1 ? Zobrist::jqeRule : 0);
}

// Only called for a check-free, reversible, complete three-occurrence interval.
Value Position::chase_result(int distance, int ply) const {
    using namespace JieqiChase;
    Board after{};
    Ids ids{};
    for (int s = 0; s < 90; ++s)
    {
        after[s] = piece_on(Square(s));
        ids[s] = s; // Any bijection identifies the same physical pieces.
    }
    Targets common[COLOR_NB];
    common[WHITE].set();
    common[BLACK].set();
    const StateInfo* cursor = st;
    Color actor = ~sideToMove;
    for (int i = 0; i < distance; ++i)
    {
        Targets newTargets = targets(after, ids, actor);
        int from = cursor->move.from_sq(), to = cursor->move.to_sq();
        assert(!cursor->capturedPiece);
        Board before = relocate(after, to, from);
        ids[from] = ids[to];
        common[actor] &= newTargets & ~targets(before, ids, actor);
        after = before;
        cursor = cursor->previous;
        actor = ~actor;
    }
    bool us = common[sideToMove].any(), them = common[~sideToMove].any();
    return us == them ? VALUE_DRAW : us ? mated_in(ply) : mate_in(ply);
}

// History requires three occurrences; a second occurrence strictly inside the
// search tree retains the existing distance < ply draw shortcut.
bool Position::rule_judge(Value& result, int ply) const {
    const bool stamped = JieqiJqeV1;
    const int limit = stamped ? 80 : 120;
    const int end = std::min(st->pliesFromNull, st->pliesSinceIrreversible);
    auto adjudicate = [&](Value value) {
        // The kernel orders mate/stalemate before repetition and the clock.
        result = MoveList<LEGAL>(*this).size() ? value : mated_in(ply);
        return true;
    };
    if (end >= 4 && filter[st->key])
    {
        const StateInfo* cursor = st;
        int matches = 0;
        bool perpetual[COLOR_NB] = {true, true};
        bool anyCheck = false;
        for (int i = 1; i <= end; ++i)
        {
            const Color mover = (i & 1) ? ~sideToMove : sideToMove;
            perpetual[mover] &= bool(cursor->checkersBB);
            anyCheck |= bool(cursor->checkersBB);
            cursor = cursor->previous;
            if (i < 4 || (i & 1) || cursor->key != st->key)
                continue;
            if (++matches < 2)
            {
                if (i < ply)
                    return adjudicate(VALUE_DRAW);
                continue;
            }
            if (!stamped)
                return adjudicate(VALUE_DRAW);
            if (perpetual[WHITE] != perpetual[BLACK])
                return adjudicate(perpetual[sideToMove] ? mated_in(ply) : mate_in(ply));
            // jqe-v1 pins mixed/intermittent check intervals to a draw.
            return adjudicate(anyCheck ? VALUE_DRAW : chase_result(i, ply));
        }
    }
    if (st->rule40 >= limit)
        return adjudicate(VALUE_DRAW);
    return false;
}


// Flips position with the white and black sides reversed. This
// is only useful for debugging e.g. for finding evaluation symmetry bugs.
void Position::flip() {

    string            f, token;
    std::stringstream ss(fen());

    for (Rank r = RANK_9; r >= RANK_0; --r)  // Piece placement
    {
        std::getline(ss, token, r > RANK_0 ? '/' : ' ');
        f.insert(0, token + (f.empty() ? " " : "/"));
    }

    ss >> token;                        // Active color
    f += (token == "w" ? "B " : "W ");  // Will be lowercased later

    ss >> token;
    f += token + " ";

    std::transform(f.begin(), f.end(), f.begin(),
                   [](char c) { return char(islower(c) ? toupper(c) : tolower(c)); });

    ss >> token;
    f += token;

    std::getline(ss, token);  // Half and full moves
    f += token;

    set(f, st);

    assert(pos_is_ok());
}


// Performs some consistency checks for the position object
// and raise an assert if something wrong is detected.
// This is meant to be helpful when debugging.
bool Position::pos_is_ok() const {

    constexpr bool Fast = true;  // Quick (default) or full check?

    if ((sideToMove != WHITE && sideToMove != BLACK) || piece_on(king_square(WHITE)) != W_KING
        || piece_on(king_square(BLACK)) != B_KING)
        assert(0 && "pos_is_ok: Default");

    if (Fast)
        return true;

    if (pieceCount[W_KING] != 1 || pieceCount[B_KING] != 1
        || checkers_to(sideToMove, king_square(~sideToMove)))
        assert(0 && "pos_is_ok: Kings");

    if ((pieces(WHITE, PAWN) & ~PawnBB[WHITE]) || (pieces(BLACK, PAWN) & ~PawnBB[BLACK])
        || pieceCount[W_PAWN] > 5 || pieceCount[B_PAWN] > 5)
        assert(0 && "pos_is_ok: Pawns");

    if ((pieces(WHITE) & pieces(BLACK)) || (pieces(WHITE) | pieces(BLACK)) != pieces()
        || popcount(pieces(WHITE)) > 16 || popcount(pieces(BLACK)) > 16)
        assert(0 && "pos_is_ok: Bitboards");

    for (PieceType p1 = PAWN; p1 <= KING; ++p1)
        for (PieceType p2 = PAWN; p2 <= KING; ++p2)
            if (p1 != p2 && (pieces(p1) & pieces(p2)))
                assert(0 && "pos_is_ok: Bitboards");

    for (Piece pc : Pieces)
        if (pieceCount[pc] != popcount(pieces(color_of(pc), type_of(pc)))
            || pieceCount[pc] != std::count(board, board + SQUARE_NB, pc))
            assert(0 && "pos_is_ok: Pieces");

    return true;
}

}  // namespace Stockfish
